# hotel/views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Room, Booking, Review, Coupon
from django.contrib import messages
from .forms import CustomUserCreationForm
from django.contrib.auth.forms import UserChangeForm
from .forms import CustomUserChangeForm, UserProfileForm
from django.http import JsonResponse
from django.db.models import Q  
from django.shortcuts import  get_object_or_404
from .models import Room, Review
from .forms import ReviewForm
from .forms import BookingEditForm

from datetime import datetime
from .forms import UserProfileForm

def booking_success(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    return render(request, 'hotel/booking_success.html', {'booking': booking})
@login_required
def profile(request):
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully.')
            return redirect('profile')
    else:
        form = UserProfileForm(instance=request.user)
    return render(request, 'hotel/profile.html', {'form': form})

@login_required
def user_bookings(request):
    bookings = Booking.objects.filter(user=request.user).distinct()  # Ensures unique bookings
    return render(request, 'hotel/bookings.html', {'bookings': bookings})


@login_required
def edit_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)

    # Pre-populate form data with user details
    initial_data = {
        'first_name': request.user.first_name,
        'last_name': request.user.last_name,
        'email': request.user.email,
        'phone_number': booking.phone_number,
        'check_in': booking.check_in,
        'check_out': booking.check_out,
    }

    if request.method == 'POST':
        form = BookingEditForm(request.POST, initial=initial_data, instance=booking)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your booking details have been updated.')
            return redirect('user_bookings')
    else:
        form = BookingEditForm(initial=initial_data, instance=booking)

    return render(request, 'hotel/edit_booking.html', {'form': form, 'booking': booking})


@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    if request.method == 'POST':
        booking.delete()
        messages.success(request, 'Your booking has been successfully canceled.')
        return redirect('user_bookings')
    return render(request, 'hotel/bookings.html')

def about(request):
    return render(request, 'hotel/about.html')

def contact(request):
    return render(request, 'hotel/contact.html')
def booking_success(request):
    return render(request, 'hotel/booking_success.html')

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect('login')  # Redirect to the login page after registration
        else:
            messages.error(request, 'Registration failed. Please check the form.')
    else:
        form = CustomUserCreationForm()
    return render(request, 'hotel/register.html', {'form': form})

from django.contrib import messages

def user_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = authenticate(request, username=email, password=password)
        
        if user is not None:
            if user.is_active:
                login(request, user)
                return redirect('dashboard')
            else:
                messages.error(request, 'Your account is disabled.', extra_tags='login')
        else:
            messages.error(request, 'Invalid email or password. Please try again.', extra_tags='login')
    
    return render(request, 'hotel/login.html')



@login_required
def user_logout(request):
    logout(request)
    return redirect('index')

@login_required
def profile(request):
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully.')
    else:
        form = UserProfileForm(instance=request.user)
    return render(request, 'hotel/profile.html', {'form': form})

@login_required
def dashboard(request):
    rooms = Room.objects.filter(availability=True)
    return render(request, 'hotel/dashboard.html', {'user': request.user, 'rooms': rooms})

def index(request):
    rooms = Room.objects.filter(availability=True)
    return render(request, 'hotel/index.html', {'rooms': rooms})


def room_list(request):
    rooms = Room.objects.filter(availability=True)
    keyword = request.GET.get('keyword', '').strip()
    check_in = request.GET.get('check_in')
    check_out = request.GET.get('check_out')
    room_type = request.GET.get('room_type')
    capacity = request.GET.get('capacity')

    # Filter based on keyword if provided
    if keyword:
        rooms = rooms.filter(
            Q(name__icontains=keyword) |  # Search in room name
            Q(description__icontains=keyword)  # Search in room description
        )

    # Filter based on check-in and check-out dates
    if check_in and check_out:
        booked_rooms = Booking.objects.filter(check_in__lt=check_out, check_out__gt=check_in).values_list('room_id', flat=True)
        rooms = rooms.exclude(id__in=booked_rooms)

    # Filter based on room type
    if room_type:
        rooms = rooms.filter(room_type=room_type)

    # Filter based on capacity
    if capacity:
        rooms = rooms.filter(capacity__gte=capacity)

    return render(request, 'hotel/rooms.html', {'rooms': rooms})


# hotel/views.py


@login_required
def book_room(request, room_id):
    room = Room.objects.get(id=room_id)
    discount = 0  # Default discount is 0
    user = request.user  # Current user details

    if request.method == 'POST':
        check_in = request.POST.get('check_in')
        check_out = request.POST.get('check_out')
        phone_number = request.POST.get('phone_number')
        coupon_code = request.POST.get('coupon_code', '').strip()

        # Validate form fields
        if not check_in or not check_out or not phone_number:
            messages.error(request, "All fields are required.")
            return render(request, 'hotel/book_room.html', {'room': room, 'user': user})

        # Calculate stay duration in days
        check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
        check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
        num_nights = (check_out_date - check_in_date).days
        if num_nights < 1:
            messages.error(request, "Check-out date must be after check-in date.")
            return render(request, 'hotel/book_room.html', {'room': room, 'user': user})

        # Calculate total cost based on number of nights
        base_cost = room.price * num_nights
        total_cost = base_cost

        # Apply coupon if provided
        if coupon_code:
            try:
                coupon = Coupon.objects.get(code=coupon_code)
                if coupon.is_active():
                    discount = float(coupon.discount)  # Coupon's discount percentage
                    total_cost -= (total_cost * discount / 100)  # Apply discount
                else:
                    messages.error(request, 'Coupon is not active.')
            except Coupon.DoesNotExist:
                messages.error(request, 'Invalid coupon code.')

        # Create a new booking with additional user details
        booking = Booking.objects.create(
            user=user,
            room=room,
            check_in=check_in,
            check_out=check_out,
            phone_number=phone_number,
            first_name=user.first_name,
            last_name=user.last_name,
            email=user.email
        )
        room.availability = False  # Update room availability
        room.save()
        messages.success(request, f"Room booked successfully! Total cost after discount: ${total_cost:.2f}")
        return redirect('booking_success')

    return render(request, 'hotel/book_room.html', {'room': room, 'discount': discount, 'total_cost': room.price, 'user': user})


def check_coupon(request):
    if request.method == "POST":
        coupon_code = request.POST.get("coupon_code", "").strip()
        if not coupon_code:
            return JsonResponse({"valid": False, "message": "No coupon code provided."}, status=400)

        try:
            # Retrieve the coupon by code and check if it's active
            coupon = Coupon.objects.get(code=coupon_code)
            if coupon.is_active():
                return JsonResponse({"valid": True, "discount": float(coupon.discount)}, status=200)
            else:
                return JsonResponse({"valid": False, "message": "Coupon is not active."}, status=400)
        except Coupon.DoesNotExist:
            return JsonResponse({"valid": False, "message": "Invalid coupon code."}, status=400)
    
    return JsonResponse({"valid": False, "message": "Invalid request."}, status=400)

@login_required
def add_review(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.user = request.user
            review.room = room
            review.save()
            messages.success(request, 'Review added successfully!')
            return redirect('dashboard')
    else:
        form = ReviewForm()
    return render(request, 'hotel/add_review.html', {'form': form, 'room': room})

@login_required
def manage_reviews(request):
    reviews = Review.objects.filter(user=request.user)
    return render(request, 'hotel/manage_reviews.html', {'reviews': reviews})

def apply_coupon(request):
    if request.method == 'POST':
        code = request.POST['code']
        try:
            coupon = Coupon.objects.get(code=code)
            discount = coupon.discount
            return render(request, 'hotel/apply_coupon.html', {'discount': discount})
        except Coupon.DoesNotExist:
            messages.error(request, 'Invalid coupon code.')
    return render(request, 'hotel/apply_coupon.html')

def all_reviews(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    reviews = Review.objects.filter(room=room)
    return render(request, 'hotel/all_reviews.html', {'room': room, 'reviews': reviews})