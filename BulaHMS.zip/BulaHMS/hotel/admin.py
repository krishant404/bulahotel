from django.contrib import admin
from .models import Room, Booking, Review, Coupon

# Display reviews inline within the room admin view
class ReviewInline(admin.TabularInline):
    model = Review
    extra = 1

# Custom admin view for Room, including inline reviews
class RoomAdmin(admin.ModelAdmin):
    list_display = ('name', 'room_type', 'price', 'availability')
    fields = ('name', 'room_type', 'description', 'price', 'capacity', 'availability', 'image')
    inlines = [ReviewInline]

# Custom admin view for Coupon to display active status dynamically
class CouponAdmin(admin.ModelAdmin):
    list_display = ('code', 'discount', 'start_date', 'end_date', 'is_active')
    readonly_fields = ('is_active',)  # Display as read-only field based on validity dates

    def is_active(self, obj):
        return obj.is_active()
    is_active.boolean = True  # Display as a boolean icon in the admin panel
    is_active.short_description = "Currently Active?"

# Register models with admin
admin.site.register(Room, RoomAdmin)
admin.site.register(Booking)
admin.site.register(Review)
admin.site.register(Coupon, CouponAdmin)
