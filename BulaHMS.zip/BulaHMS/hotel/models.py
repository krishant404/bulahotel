# hotel/models.py
from django.db import models
from django.contrib.auth.models import AbstractUser
import datetime
from django.contrib.auth.models import BaseUserManager
from django.contrib.auth.models import AbstractUser, UserManager as DefaultUserManager

class CustomUserManager(DefaultUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)  # Hash the password
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        # Ensure the superuser is given a unique email
        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(email, password, **extra_fields)

class CustomUser(AbstractUser):
    username = None
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=15)
    profile_picture = models.ImageField(upload_to='profile_pictures/', blank=True, null=True)

    REQUIRED_FIELDS = ['first_name', 'last_name', 'phone_number']
    USERNAME_FIELD = 'email'

    def __str__(self):
        return self.email

class Room(models.Model):
    ROOM_TYPES = [
        ('single', 'Single'),
        ('double', 'Double'),
        ('king', 'King'),
        ('suite', 'Suite'),
    ]

    name = models.CharField(max_length=100)
    room_type = models.CharField(max_length=10, choices=ROOM_TYPES)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    capacity = models.IntegerField()
    availability = models.BooleanField(default=True)
    image = models.ImageField(upload_to='room_images/', blank=True, null=True)  # Add this line

    
    name = models.CharField(max_length=100)
    description = models.TextField()  # Ensure you have this field
    # Other fields such as availability, price, room_type, etc.

    def __str__(self):
        return self.name


class Booking(models.Model):
    user = models.ForeignKey('hotel.CustomUser', on_delete=models.CASCADE)
    room = models.ForeignKey('Room', on_delete=models.CASCADE)
    check_in = models.DateField()
    check_out = models.DateField()
    phone_number = models.CharField(max_length=15)
    
    # New fields for user details
    first_name = models.CharField(max_length=30, blank=True, null=True)
    last_name = models.CharField(max_length=30, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)

    def __str__(self):
        return f'{self.first_name} {self.last_name} - {self.room}'

class Review(models.Model):
    user = models.ForeignKey('hotel.CustomUser', on_delete=models.CASCADE)
    room = models.ForeignKey('Room', on_delete=models.CASCADE)
    review = models.TextField(max_length=100)

    def __str__(self):
        return f'Review by {self.user.first_name} for {self.room}'

from django.utils import timezone

class Coupon(models.Model):
    code = models.CharField(max_length=10, unique=True)
    discount = models.DecimalField(max_digits=4, decimal_places=2)
    start_date = models.DateField(null=True, blank=True)  # Allow null values
    end_date = models.DateField(null=True, blank=True)    # Allow null values

    def is_active(self):
        current_date = timezone.now().date()
        # Check if start_date and end_date are set, and if the current date is within the range
        if self.start_date and self.end_date:
            return self.start_date <= current_date <= self.end_date
        # If only start_date is set, check if current date is after start_date
        elif self.start_date:
            return self.start_date <= current_date
        # If only end_date is set, check if current date is before end_date
        elif self.end_date:
            return current_date <= self.end_date
        # If neither are set, consider it inactive
        return False

    def __str__(self):
        return f"Coupon {self.code} - {self.discount}%"

