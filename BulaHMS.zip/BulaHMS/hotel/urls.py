from django.urls import path
from . import views  # This will import all views including booking_success
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [

    path('', views.index, name='index'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('user_logout/', views.user_logout, name='user_logout'),
    path('profile/', views.profile, name='profile'),
    path('review/<int:room_id>/', views.add_review, name='add_review'),
    path('manage_reviews/', views.manage_reviews, name='manage_reviews'),
    path('dashboard/', views.dashboard, name='dashboard'),
     path('bookings/', views.user_bookings, name='user_bookings'),
    path('cancel_booking/<int:booking_id>/', views.cancel_booking, name='cancel_booking'),
    path('edit_booking/<int:booking_id>/', views.edit_booking, name='edit_booking'),
    path('rooms/', views.room_list, name='room_list'),
    path('book/<int:room_id>/', views.book_room, name='book_room'),
    path('apply_coupon/', views.apply_coupon, name='apply_coupon'),
    path('check_coupon/', views.check_coupon, name='check_coupon'),
    path('check_coupon/', views.check_coupon, name='check_coupon'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
        path('reviews/<int:room_id>/', views.all_reviews, name='all_reviews'),  # New URL for all reviews

    path('booking_success/', views.booking_success, name='booking_success'),  # Ensure the view is accessed properly
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
